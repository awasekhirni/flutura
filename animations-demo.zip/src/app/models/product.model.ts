export class Product{
    constructor(public id:number,public productName:string,public productPrice:number,public productDesc:string,public productIsonsale:boolean,public state:string){}
}