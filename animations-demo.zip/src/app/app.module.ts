import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CommonModule} from '@angular/common';

import { AppComponent } from './app.component';

import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { ProductComponent } from './components/product.component';
import { ProductDetailComponent } from './components/product-detail.component';
import { AddProductComponent } from './components/addproduct.component';
import { AppRoutingModule } from './routes/main.routes';
import { ProductService } from './services/product.service';
@NgModule({
  declarations: [
    AppComponent,ProductComponent,ProductDetailComponent,AddProductComponent
  ],
  imports: [
    BrowserModule,BrowserAnimationsModule,CommonModule,FormsModule, ReactiveFormsModule,AppRoutingModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
