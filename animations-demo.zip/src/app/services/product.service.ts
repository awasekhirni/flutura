import { Injectable } from '@angular/core';
import { Product } from '../models/product.model';

const Productlist:Product[]=[
    {"id":1,"productName":"Galaxy S2","productPrice":54000,"productDesc":"Qualcomm processor 840","productIsonsale":true,"state":'off'},
    {"id":2,"productName":"Galaxy S3","productPrice":34000,"productDesc":"Qualcomm processor 625","productIsonsale":false,"state":'off'},
    {"id":3,"productName":"Galaxy S6","productPrice":64000,"productDesc":"Qualcomm processor 450","productIsonsale":false,"state":'off'},
    {"id":4,"productName":"Galaxy S7","productPrice":24000,"productDesc":"Qualcomm processor 935","productIsonsale":false,"state":'off'},
    {"id":5,"productName":"Galaxy S8","productPrice":14000,"productDesc":"Qualcomm processor 450","productIsonsale":true,"state":'off'},
    {"id":6,"productName":"Galaxy S9","productPrice":44000,"productDesc":"Qualcomm processor 650","productIsonsale":true,"state":'off'},
]
let productPromise=Promise.resolve(Productlist);

@Injectable()
export class ProductService {

    constructor() { }

    getProducts():Promise<Product[]>{
        return productPromise;
    
    }

    addProduct(product:Product):Promise<Product>{
        return this.getProducts().then(products=>{
            let ttlNo=products.length-1;
            let productfinalIndex =products[ttlNo];
            product.id= productfinalIndex.id+1;
            product.state='off';
            products.push(product);
            return product;
        });
    }
}