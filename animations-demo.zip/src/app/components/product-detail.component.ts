import { Component, OnInit, HostBinding } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Product } from '../models/product.model';
import { FLY_IN_OUT_ANIMATION } from '../animations/flyinout.animation';

@Component({
    selector: 'app-productdetail',
    templateUrl: './product-detail.view.html',
    animations:[
        FLY_IN_OUT_ANIMATION
    ]
})

export class ProductDetailComponent implements OnInit {
    @HostBinding('@flyInoutTrigger') flyInOutTrigger ='in';
    products: Promise<Product[]>;
    constructor(private _ps:ProductService) { }

    ngOnInit() {
        this.products= this._ps.getProducts();
     }
}