import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Product } from '../models/product.model';
import { ON_OFF_1_ANIMATION } from '../animations/onoffUno.animation';
import { ON_OFF_2_ANIMATION } from '../animations/onoffDuos.animation';
import { ON_OFF_3_ANIMATION } from '../animations/onofftres.animation';
import { ON_OFF_4_ANIMATION } from '../animations/onoffQuatro.animation';
import { ROTATE_ONEEIGHTY_ANIMATION } from '../animations/Rotate180.animation';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { SHOW_HIDE_ELEMENTS } from '../animations/showhideelements.animation';
import { SELECTED_HIGHLIGHTER_ANIMATE } from '../animations/selected.animate';
import { ENTER_LEAVE_ANIMATE } from '../animations/enterleave.animate';
import { TICKER_ANIMATE } from '../animations/ticker.animate';
import { COLLAPSE_ANIMATE } from '../animations/collapse.animate';
import { FLIPIT_ANIMATION } from '../animations/flipit.animate';
@Component({
    selector: 'app-product',
    templateUrl: './product.view.html',
    animations:[
        ON_OFF_1_ANIMATION,
        ON_OFF_2_ANIMATION,
        ON_OFF_3_ANIMATION,
        ON_OFF_4_ANIMATION,
        ROTATE_ONEEIGHTY_ANIMATION,
        SHOW_HIDE_ELEMENTS,
        SELECTED_HIGHLIGHTER_ANIMATE,
        ENTER_LEAVE_ANIMATE,
        TICKER_ANIMATE,
        COLLAPSE_ANIMATE,
        FLIPIT_ANIMATION
    ],
    styleUrls:["./product.view.css"]
})

export class ProductComponent implements OnInit {
    products: Promise<Product[]>;
    state: string = 'default';
    displayit=true;
    tickerShow:boolean=true;
    isOpen=true;
    isFlipped='inactive';

    images = [ 
        'https://placeimg.com/300/300/nature/6',
        'https://placeimg.com/300/300/nature/7',
        'https://placeimg.com/300/300/nature/8',
        'https://placeimg.com/300/300/nature/9',
        'https://placeimg.com/300/300/nature/2',
        'https://placeimg.com/300/300/nature/3',
        'https://placeimg.com/300/300/nature/1',
      ];

    flipthem(){
        this.isFlipped=this.isFlipped==='inactive'? 'active':'inactive';
    }
    get collapseState(){
        return this.isOpen? 'open':'close';
    }
    
    shoppinglist: any;
    constructor(private _ps:ProductService) { }

    ngOnInit() {
        this.products=this._ps.getProducts();

        setInterval(()=>{
            this.tickerShow=!this.tickerShow;}
        ,2000);
     }

     toggle(product:Product){
         product.state=(product.state==='on')? 'off':'on';
     }

     flatit(){
         this.isOpen=!this.isOpen;
     }
     
     rotate() {
        this.state = (this.state === 'default' ? 'rotated' : 'default');
    }
    logAnimation(_event) {
        console.log(_event)
      }
    showhide(){
        this.shoppinglist >0? this.hideItems() : this.showItems();
    }

    showItems() {
      this.shoppinglist=[
        {
            "product_id":"00001", "count":2, "price_unit":3.99, "selected":'notSelected'
        },
        {
            "product_id":"00013","count":1, "price_unit":2.00,"selected":'notSelected'
        },
        {
            "product_id":"02019",  "count":4, "price_unit":0.70,"selected":'notSelected'
        }
    ];
    
      }
    
      hideItems() {
        this.shoppinglist = [];
      }
    
    
}

