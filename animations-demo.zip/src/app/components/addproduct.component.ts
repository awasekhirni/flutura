import { Component, OnInit, HostBinding } from '@angular/core';
import { ProductService } from '../services/product.service';
import {Router} from '@angular/router';
import {Product} from '../models/product.model';
import { ROUND_ANTICLOCK_ANIMATION } from '../animations/roundAnticlock.animation';

@Component({
    selector: 'app-addproduct',
    templateUrl: './addproduct.view.html',
    animations:[
        ROUND_ANTICLOCK_ANIMATION

    ],
    styles:[':host { position: absolute; top: 20%; left: 5%; border: 3px solid black; }']
})

export class AddProductComponent implements OnInit {
    @HostBinding('@roundAntiClockTrigger') roundAntiClockTrigger='in';
    
    constructor(private _ps:ProductService, private router:Router) { }

    ngOnInit() { }

    add(id,productName,productPrice,productDesc,productIsOnSale,state){
        this._ps.addProduct(new Product(id,productName,productPrice,productDesc,productIsOnSale,state)).then(
            ()=>this.router.navigate(['/product'])
        );
    }
}