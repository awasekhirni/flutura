import {trigger,state,style,animate,transition, group} from '@angular/animations';

export const ENTER_LEAVE_ANIMATE=  trigger('enterLeave', [
     transition('void => *', [
      // 'From' styles
      style({
        opacity: 0.2,
        transform: 'translateX(-100vw)'
      }),
      animate('3000ms ease-in',
       style({
          opacity: 1,
          transform: 'scale(1.2)'
        })
      )
    ]),
    transition('* => void', [
        animate('3000ms ease-in-out',
          style({
            opacity: 0.2,
            transform: 'translateX(100%)'
          })
        )
      ]),
      transition('* => void', [
        group([
          animate('1s ease',
            style({
              backgroundColor: '#ffc107'
            })
          ),
          animate('2s 1.5s ease',
            style({
              opacity: 0.2,
              transform: 'translateX(100%)'
            })
          ),
        ])
      ]) 
    ]);