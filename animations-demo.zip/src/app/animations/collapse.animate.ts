import {trigger,state,style,transition,animate, AnimationBuilder, AnimationPlayer } from '@angular/animations';

export const COLLAPSE_ANIMATE=
trigger('collapse', [
    state('open', style({ width: '*' })),
    state('close', style({ width: 0 })),
    transition('open => close', [
      style({ width: '*' }),
      animate(200, style({ width: 0 }))
    ]),
    transition('close => open', [
      style({ width: 0 }),
      animate(200, style({ width: '*' }))
    ])
  ]);