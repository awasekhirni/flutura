import {animate,trigger,style,transition} from '@angular/animations';

export const TICKER_ANIMATE=trigger('tickerScroll',[
    transition(':enter',
      animate('3s',
        style({transform: 'translateX(300%)', opacity: '30'})
      )
    )
  ]);