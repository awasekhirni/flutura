import {animate,transition,style, state,trigger}from '@angular/animations'; 

export const EASEINOUT_ANIMATE=trigger('@easeInOut',[
    state('shrink',style({
        transform:'scale(1)'
    })),
    state('expand',style({
        transform:'scale(2)'
    })),
    transition('shrink=>expand',animate('700ms')),
    transition('expand=>shrink',animate('700ms'))
    //transition('shrink<=>expand',animate('700ms'));
    //transition('shrink=>expand', 'expand=>shrink',animate('700ms'));
])