import {animate,state,style,transition, trigger, sequence} from '@angular/animations';

export const ROTATE_ONEEIGHTY_ANIMATION=
trigger('rotateOneEightyTrigger',[
    state('default', style({ transform: 'rotate(0)' })),
    state('rotated', style({ transform: 'rotate(-180deg)' })),
    transition('rotated => default', animate('1500ms ease-out')),
    transition('default => rotated', animate('400ms ease-in'))
]);





