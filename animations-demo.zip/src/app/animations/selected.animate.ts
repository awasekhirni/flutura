import {trigger,state,style,animate,transition, group} from '@angular/animations';

export const SELECTED_HIGHLIGHTER_ANIMATE=
trigger('selectedHighlighter', [
    state('selected',
      style({
        backgroundColor: 'red',
        transform: 'scale(2)',
      })
    ),
   
    transition('selected <=> *', [
      animate('500ms ease-in')
    ]),
    
     transition('selected => *', [       
      group([
        animate('1s ease',
          style({
            backgroundColor: '#ff4081'
          })
        ),
        // after a second, fade it to the background 
        animate('2s 1.5s ease',
          style({
            opacity: 0.2,
            transform: 'scale(0.5)'
          })
        ),
      ])
    ])
  ])