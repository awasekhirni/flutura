import { NgModule }      from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductDetailComponent } from '../components/product-detail.component';
import { AddProductComponent } from '../components/addproduct.component';
import { ProductComponent } from '../components/product.component';



const routes: Routes = [
	{
	   path: 'product',
	   component: ProductComponent, data:{preload:true}
	},
	{
	   path: 'add-product',
	   component: AddProductComponent,data:{preload:true}
	},	
	{
	   path: 'product-detail',
	   component: ProductDetailComponent,data:{preload:true}
	},	
	{
	   path: '',
	   redirectTo: '/product',
	   pathMatch: 'full'
	}	
];
@NgModule({
  imports: [ 
          RouterModule.forRoot(routes) 
  ],
  exports: [ 
          RouterModule 
  ]
})
export class AppRoutingModule{ } 