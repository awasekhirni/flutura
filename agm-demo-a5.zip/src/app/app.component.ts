import { Component, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
declare var google: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
   startpoint: Object = { lat:12.9716, lng: 77.5946 };
  map: Object;
  marker: Object;
  zoom: number;
  @ViewChild('map') mapRef: ElementRef;
  ngAfterViewInit() {
    //used setTimeout google map is delayed in loading, in stackBlitz

    setTimeout(() => {
      this.map = new google.maps.Map(this.mapRef.nativeElement, {
        zoom: 4,
        center: this.startpoint
      });
      this.marker = new google.maps.Marker({
        position: this.startpoint,
        map: this.map
      });

    }, 2000)

    //console.log(this.map.getZoom())
  }
  reset() {
    this.startpoint = { lat:12.9716, lng: 77.5946 };
    this.map = new google.maps.Map(this.mapRef.nativeElement, {
      zoom: 4,
      center: this.startpoint
    });
    this.marker = new google.maps.Marker({
      position: this.startpoint,
      map: this.map
    });
  }
  updateMap(lats: number, lon: number) {
    //this.zoom = this.map.getZoom();
    this.zoom=5;
    alert('current zoom=' + this.zoom)
    this.startpoint = { lat: lats, lng: lon };
    this.map = new google.maps.Map(this.mapRef.nativeElement, {
      zoom: this.zoom,
      center: this.startpoint
    });
    this.marker = new google.maps.Marker({
      position: this.startpoint,
      map: this.map
    });
  }

}
