import { Component, OnInit } from '@angular/core';
import { MenuRenderService } from '../common/services/menurender.service';
import {Http,HttpModule,Request,Response,ResponseOptions} from '@angular/http';
import {Observable} from 'rxjs/Rx'; 

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.view.html'
})

export class DashboardComponent implements OnInit {
    menuLinks: any[];
    constructor(private _mrs:MenuRenderService) { }

    ngOnInit() { 

       
            return this._mrs.getMenuData().subscribe(results=>{
                this.menuLinks=results;
                console.log(results);
            });
           
      


    }
}