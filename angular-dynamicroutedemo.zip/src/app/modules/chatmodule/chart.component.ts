import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-chart',
    templateUrl: './chart.view.html'
})

export class ChartComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}