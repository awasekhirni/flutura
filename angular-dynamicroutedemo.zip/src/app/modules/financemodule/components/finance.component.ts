import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-finance',
    templateUrl: './finance.view.html'
})

export class FinanceComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}