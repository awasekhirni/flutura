import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-profile',
    templateUrl: './profile.view.html'
})

export class ProfileComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}