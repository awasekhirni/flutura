import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-hrd',
    templateUrl: './hrd.view.html'
})

export class HrdComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}