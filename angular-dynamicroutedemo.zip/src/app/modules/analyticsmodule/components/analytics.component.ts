import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-analytics',
    templateUrl: './analytics.view.html'
})

export class AnalyticsComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}