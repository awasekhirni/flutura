export class MenuItem{
    constructor(public path:string, public componentName:Object, public data:string){}
}