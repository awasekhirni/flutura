import { Injectable } from '@angular/core';
import {Http,HttpModule,Request,Response,ResponseOptions,RequestOptions} from '@angular/http'; 
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { MenuItem } from '../models/menuitem.model';

@Injectable()
export class MenuRenderService {
    activeMenuItem$:Observable<MenuItem>;
    menuUrl="https://raw.githubusercontent.com/awasekhirni/jsondata/master/dynamicroute.json";
    constructor(private _http:Http) { }

    getMenuData(){
        return this._http.get(this.menuUrl).map((response: Response) => response.json()).catch(this.handleError);
    }


    handleError(error: any): any {
        return "error";
    }
}