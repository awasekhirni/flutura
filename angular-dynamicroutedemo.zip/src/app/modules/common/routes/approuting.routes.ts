import { NgModule, OnInit,Component } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { MenuRenderService } from '../services/menurender.service';
import { MenuItem } from '../models/menuitem.model';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


//components


import { FinanceComponent } from '../../financemodule/components/finance.component';
import { DashboardComponent } from '../../dashboardmodule/welcome.component';
import { AnalyticsComponent } from '../../analyticsmodule/components/analytics.component';
import { AdminComponent } from '../../adminmodule/components/admin.component';
import { ReportsComponent } from '../../reportsmodule/components/reports.component';
import { HrdComponent } from '../../hrdmodule/components/hrd.component';
import { ProfileComponent } from '../../profilemodule/components/profile.component';
import { ChartComponent } from '../../chatmodule/chart.component';
import { StockComponent } from '../../stockmodule/components/stock.component';
import { SalesComponent } from '../../salesmodule/components/sales.component';




const routes: Routes = [
    { path: '**', redirectTo: "home" },
    {
        path: "home/finance",
        component: JSON.parse("FinanceComponent"),
        data: {"preload":true, "title":"Finance Component"}
      }
];




@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule implements OnInit {

    menuLinks: any[];
    
    constructor(private _mrs: MenuRenderService, private myrouter: Router, routerModule: RouterModule) {

        console.log(routes);
    }


    ngOnInit() {
        console.log("inside route constructor");
        this._mrs.getMenuData().subscribe(results => {
            this.menuLinks = results;
            console.log("inside subscribe")

           console.log(this.menuLinks);
        });
        console.log("ooutside" + this.menuLinks[0].pathName);
        //let limit=this.menuLinks.length;
        let limit = 10;
        if (limit != 0) {
            const config = this.myrouter.config;
            for (let i = 0; i < limit; i++) {
              console.log(this.menuLinks[i].pathName + " " + this.menuLinks[i].componentName + " " + this.menuLinks[i].dataContext);
              let myobj=Object.assign({},  JSON.parse(this.menuLinks[i].componentName.value), {
                component:this.menuLinks[i].componentName.value
              });
             config.push({ path: this.menuLinks[i].pathName, component: myobj, data: this.menuLinks[i].dataContext })
              //config.push({ path: this.menuLinks[i].pathName, component: SalesComponent, data: this.menuLinks[i].dataContext })
            }
            this.myrouter.resetConfig(config);

            routes.forEach((x, i) => {
                console.log(`${i}: ${JSON.stringify(x, undefined, 1)}`);
            });
        }
    }

}

