import { Directive,ViewContainerRef } from '@angular/core';

@Directive({ selector: '[tab-smile]' })
export class TabSmileDirective {
    constructor(public viewContainer:ViewContainerRef) { }
}