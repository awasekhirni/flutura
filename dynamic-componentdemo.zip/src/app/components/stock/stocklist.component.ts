import { Component, Input, Output, EventEmitter } from '@angular/core';


@Component({
    selector: 'app-stocklist',
    templateUrl: './stocklist.view.html'
})

export class StockListComponent  {
    @Input() stocklist;
    @Output() addStock = new EventEmitter<any>();
    @Output() editStock = new EventEmitter<any>();
}