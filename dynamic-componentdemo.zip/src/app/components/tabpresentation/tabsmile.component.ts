import { Component, OnInit,Input,ContentChildren,QueryList, AfterContentInit,ViewChild, ComponentFactoryResolver,ViewContainerRef } from '@angular/core';

@Component({
    selector: 'app-tabsmile',
    templateUrl: './tabsmile.view.html',
    styles:[
        `
    .panel{
      padding: 2em;
    }
  `
    ]
})

export class TabsmileComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
    @Input('tabTitle') title:string;
    @Input() active=false;
    @Input() isCloseable = false;
    @Input() template;
    @Input() dataContext;
}