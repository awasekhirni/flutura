import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-admin',
    templateUrl: './admin.view.html'
})

export class AdminComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}