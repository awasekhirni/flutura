import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ComponentFactory } from '@angular/core';

import { AppComponent } from './app.component';
import {HttpModule} from '@angular/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { DollarParentComponent } from './components/dollarparent.component';
import { ChildOneComponent } from './components/childone.component';
import { ChildTwoComponent } from './components/childtwo.component';

@NgModule({
  declarations: [
    AppComponent,DollarParentComponent,ChildOneComponent,ChildTwoComponent
  ],
  imports: [
    BrowserModule, 
    HttpModule, 
    FormsModule, 
    ReactiveFormsModule,
  ],
  providers: [],
  entryComponents:[DollarParentComponent,ChildOneComponent,ChildTwoComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
