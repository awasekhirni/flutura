import { Component, OnInit,ComponentFactoryResolver, ComponentRef, } from '@angular/core';
import { ChildBaseComponent } from './childbase.component';

@Component({
    selector: 'app-childone',
    template: '<h1>Pinging from ChildOne Component</h1>'
})

export class ChildOneComponent extends ChildBaseComponent {
    constructor() { 
        super();
        console.log("ChildOne Component");
    }

   
}