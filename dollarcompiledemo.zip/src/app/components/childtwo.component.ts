import { Component, OnInit,ComponentFactoryResolver, ComponentRef} from '@angular/core';
import { ChildBaseComponent } from './childbase.component';

@Component({
    selector: 'app-childtwo',
    template: '<h1>Pinging from ChildTwo Component</h1>'
})

export class ChildTwoComponent extends ChildBaseComponent {
    constructor() { 
        super();
        console.log("ChildTwo Component");
    }

   
}