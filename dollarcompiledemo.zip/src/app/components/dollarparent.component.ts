import { Component, Input,	ViewChild,	ViewContainerRef,	ComponentFactoryResolver, ComponentRef, AfterContentInit,OnChanges } from '@angular/core';
import { ChildBaseComponent } from './childbase.component';
import { ChildOneComponent } from './childone.component';
import { ChildTwoComponent } from './childtwo.component';

@Component({
    selector: 'app-dollarparent',
    templateUrl: './dollar.view.html'
})

export class DollarParentComponent implements AfterContentInit,OnChanges  {
    @Input() child: string;
    @Input() value: string;
    
    //Get tag child component will be placed
    @ViewChild('target', { read: ViewContainerRef }) target: ViewContainerRef;
	private componentRef:ComponentRef<any>;

	//Child components
    private children = {
    	child1: ChildOneComponent,
    	child2: ChildTwoComponent
    };
    
    constructor(private compiler: ComponentFactoryResolver) {}

    //Pass through value to child component
    renderComponent(){
		if (this.componentRef) this.componentRef.instance.value = this.value;
	}

	//Compile child component
    ngAfterContentInit() {
    	let childComponent = this.children[this.child || 'child2'];
        //Resolve child component
        let componentFactory = this.compiler.resolveComponentFactory(childComponent);
        this.componentRef = this.target.createComponent(componentFactory);
        this.renderComponent();
    }

    //Pass through value to child component when value changes
	ngOnChanges(changes: Object) {
		this.renderComponent();
	}

   
}