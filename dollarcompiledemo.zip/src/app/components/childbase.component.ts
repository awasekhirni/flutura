import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-childbase',
    templateUrl: './childbase.view.html'
})

export class ChildBaseComponent  {
    constructor() { }

  
}