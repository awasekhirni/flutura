import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {RouterModule,Routes} from '@angular/router';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {HttpModule,JsonpModule} from '@angular/http';
import { DashboardComponent } from './modules/dashboardmodule/welcome.component';
import { MenuRenderService } from './modules/common/services/menurender.service';
import { FinanceComponent } from './modules/financemodule/components/finance.component';
import { AnalyticsComponent } from './modules/analyticsmodule/components/analytics.component';
import { AdminComponent } from './modules/adminmodule/components/admin.component';
import { ReportsComponent } from './modules/reportsmodule/components/reports.component';
import { SalesComponent } from './modules/salesmodule/components/sales.component';
import { StockComponent } from './modules/stockmodule/components/stock.component';
import { ChartComponent } from './modules/chatmodule/chart.component';
import { ProfileComponent } from './modules/profilemodule/components/profile.component';
import { HrdComponent } from './modules/hrdmodule/components/hrd.component';
import { AppRoutingModule } from './modules/common/routes/approuting.routes';
import { NameResolverService } from './modules/common/services/nameresolver.service';
import { PageNotFoundComponent } from './modules/common/components/pagenotfound.component';

@NgModule({
  declarations: [
    AppComponent,DashboardComponent,FinanceComponent,
    AnalyticsComponent,    AdminComponent,
       ReportsComponent, SalesComponent,    StockComponent,    ChartComponent,
    ProfileComponent,    HrdComponent, PageNotFoundComponent
  ],
  imports: [
    BrowserModule,RouterModule,FormsModule,ReactiveFormsModule,JsonpModule,HttpModule,AppRoutingModule
  ],
  providers: [MenuRenderService,NameResolverService],
  bootstrap: [AppComponent]
})
export class AppModule { }
