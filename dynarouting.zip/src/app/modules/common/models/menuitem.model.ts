export class MenuItem{
    constructor(public path:string, public component:Object, public data:string){}
}