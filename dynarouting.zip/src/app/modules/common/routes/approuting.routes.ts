import { NgModule, OnInit,Component,ComponentRef,ComponentFactoryResolver} from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { MenuRenderService } from '../services/menurender.service';
import { MenuItem } from '../models/menuitem.model';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


//components


import { FinanceComponent } from '../../financemodule/components/finance.component';
import { DashboardComponent } from '../../dashboardmodule/welcome.component';
import { AnalyticsComponent } from '../../analyticsmodule/components/analytics.component';
import { AdminComponent } from '../../adminmodule/components/admin.component';
import { ReportsComponent } from '../../reportsmodule/components/reports.component';
import { HrdComponent } from '../../hrdmodule/components/hrd.component';
import { ProfileComponent } from '../../profilemodule/components/profile.component';
import { ChartComponent } from '../../chatmodule/chart.component';
import { StockComponent } from '../../stockmodule/components/stock.component';
import { SalesComponent } from '../../salesmodule/components/sales.component';
import { NameResolverService } from '../services/nameresolver.service';
import { PageNotFoundComponent } from '../components/pagenotfound.component';




const routes: Routes = [
    // { path: '**', redirectTo: "home" },
    // {path: "home/sales", component: SalesComponent, data: {preload:true}},
    // { path: "home/finance", component: FinanceComponent, data: {preload:true} },
    // { path: "home/hrd", component: HrdComponent, data: {preload:true} },
    // { path: "home/admin", component: AdminComponent, data: {preload:true} }
   // { path: '', component: HomeComponent },
 // { path: '**', component: NotFoundComponent }
];




@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule {

    menuLinks: any[];
   
    
    constructor(private componentFactoryResolver: ComponentFactoryResolver,private _mrs: MenuRenderService, private _check:ComponentFactoryResolver,private myrouter: Router, routerModule: RouterModule) {

        // routes.push( { path: '**', redirectTo: "home" })
        // routes.push({ path: "home/sales", component: SalesComponent, data: {preload:true} })
        // routes.push({ path: "home/finance", component: FinanceComponent, data: {preload:true} })
        // routes.push({ path: "home/hrd", component: HrdComponent, data: {preload:true} })
        // routes.push({ path: "home/admin", component: AdminComponent, data: {preload:true} })
     // console.log(routes)
      this.fetchroutes();
    }


    // nameResolution(argument0:string):Component{
        
    //     switch(argument0){
    //         case("HrdComponent"):{ return HrdComponent}
    //         case("AdminComponent"):{ return AdminComponent}
    //         case("salesComponent"):{ return SalesComponent}
    //     }

    //     return HomeComponent;
    // }

    fetchroutes(){
        const config = this.myrouter.config;
        this._mrs.getMenuData().subscribe(results => {
            this.menuLinks = results;
            console.log("inside subscribe")
            for (let i = 0; i < 10; i++) {
            
            this.myrouter.config.unshift({ path: this.menuLinks[i].pathName,component: this.menuLinks[i].componentName, data: this.menuLinks[i].dataContext })
           // routes.push({ path: this.menuLinks[i].pathName, component:  this.menuLinks[i].componentName, data: this.menuLinks[i].dataContext })
            }
           // console.log(this.menuLinks);
           this.myrouter.config.unshift({ path: '', component: DashboardComponent });
           this.myrouter.config.unshift({ path: '**', component: PageNotFoundComponent })
          
            console.log(this.myrouter);
         });


    };
   


    }

   



