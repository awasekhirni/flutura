import { Injectable,ComponentFactoryResolver,Component } from '@angular/core';

@Injectable()
export class NameResolverService {

    constructor(private _cfr:ComponentFactoryResolver) { }

    // getCompName():Component{
    //     this._cfr.resolveComponentFactory.name.
    //     return 
    // }
}