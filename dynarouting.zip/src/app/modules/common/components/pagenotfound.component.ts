import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-pagenotfound',
    templateUrl: './pagenotfound.view.html'
})

export class PageNotFoundComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}