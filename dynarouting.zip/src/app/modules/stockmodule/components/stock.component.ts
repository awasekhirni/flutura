import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-stock',
    templateUrl: './stock.view.html'
})

export class StockComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}