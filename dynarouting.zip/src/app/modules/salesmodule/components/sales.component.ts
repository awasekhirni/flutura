import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-sales',
    templateUrl: './sales.view.html'
})

export class SalesComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}